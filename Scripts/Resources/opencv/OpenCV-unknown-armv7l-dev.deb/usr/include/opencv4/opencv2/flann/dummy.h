
#ifndef OPENCV_FLANN_DUMMY_H_
#define OPENCV_FLANN_DUMMY_H_

namespace cvflann
{

CV_DEPRECATED inline void dummyfunc() {}

}


#endif  /* OPENCV_FLANN_DUMMY_H_ */
