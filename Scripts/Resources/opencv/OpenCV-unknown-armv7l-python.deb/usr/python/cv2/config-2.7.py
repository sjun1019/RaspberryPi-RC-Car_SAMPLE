PYTHON_EXTENSIONS_PATHS = [
    os.path.join(os.path.join(LOADER_DIR, '../../'), 'python/cv2/python-2.7')
] + PYTHON_EXTENSIONS_PATHS
